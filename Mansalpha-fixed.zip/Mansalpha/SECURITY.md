# Security policy

Security fixes target the current `main` branch (application version 1.x).

Report vulnerabilities privately through this repository's **Security → Report
a vulnerability** option when available. If private reporting is disabled, ask
the maintainer to enable it without publishing exploit details, credentials or
personal data. No response-time guarantee is currently defined.

Never commit `.env` files, signing keys, database exports or private migration
inputs. Rotate accidentally published credentials: deleting a file does not
remove it from Git history. `MANUS_API_BROWSER_KEY` is deliberately public;
`MANUS_API_KEY`, `MANUS_JWT_SECRET` and `DATABASE_URL` stay server-side.

/** Public application routes, shared by the browser and HTTP fallback. */
export const APP_PATHS = [
  "/",
  "/pregled",
  "/knjiznica",
  "/clanci",
  "/prezentacije",
  "/videozapisi",
  "/izvori",
  "/dogadaji",
  "/ideje",
  "/predavanje",
  "/predlosci",
  "/postavke",
] as const;

export function isAppPath(pathname: string): boolean {
  return (APP_PATHS as readonly string[]).includes(pathname);
}

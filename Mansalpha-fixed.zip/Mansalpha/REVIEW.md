# Pregled i pripremljeni popravci

Izmjene su pripremljene lokalno na grani `fix/repository-and-runtime`.
Nisu poslane na GitHub niti objavljene na aktivnoj domeni.

- Nepostojeće stranice i datoteke vraćaju 404 umjesto 200; nepostojeći API vraća JSON 404.
- Klijent i poslužitelj koriste zajednički popis ruta. 404 prikaz čuva izvornu adresu.
- Pristup localStorage više ne ruši prijavu i temu kad je pohrana blokirana.
- Prikaz sadržaja učitava se odvojeno, tek kad je potreban.
- Dodani su .gitignore, .dockerignore, .env.example i GitHub Actions provjere.
- README i sigurnosna politika zamjenjuju ostatke predloška stvarnim uputama.

Provjere: TypeScript prolazi, 79 testova prolazi, produkcijska izgradnja prolazi.
Izgradnja još upozorava na velike biblioteke za prikaz sadržaja i na namjerno
vanjski runtime konfiguracijski skript. Odgođeno učitavanje smanjuje početni
paket, ali ne uklanja veličinu tih biblioteka.

Ograničenja: stvarna OAuth prijava, MySQL spremanje, Docker i objava nisu
provjereni na produkcijskoj infrastrukturi. Mediji pod /manus-storage/ ovise o
Manus infrastrukturi. Postojeća noindex,nofollow postavka ostaje; uključivanje
indeksiranja zahtijeva uredničku odluku o spremnosti javnog sadržaja.

Za primjenu patcha u čistom checkoutu iste verzije:

    git apply --check /putanja/Mansalpha-fixes.patch
    git apply /putanja/Mansalpha-fixes.patch

Zatim pokrenuti pnpm install --frozen-lockfile, pnpm check, pnpm test i pnpm build.

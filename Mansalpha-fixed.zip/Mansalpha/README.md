# MansAlpha — znanje, čovjek i tehnologija

Edukativna platforma na hrvatskom jeziku: React 19, Vite, Express, tRPC i MySQL/Drizzle.
Javna stranica: https://mansalpha.live.

## Lokalno pokretanje

Potreban je Node.js 22.12+ i pnpm 10.18.0 (naveden u `package.json`).

```sh
corepack enable
pnpm install --frozen-lockfile
cp .env.example .env
pnpm dev
```

Aplikacija sluša na `http://localhost:3000`; port mijenja varijabla `PORT`.
Gosti mogu pregledavati početni edukativni sadržaj bez baze i prijave.
Za prijavu i spremanje privatnih radnih prostora postavite stvarne Manus OAuth
vrijednosti, `MANUS_JWT_SECRET` i MySQL `DATABASE_URL` u `.env`, pa pokrenite
`pnpm db:migrate`. Prijava koristi sigurne HTTPS kolačiće; za provjeru prijave
potrebna je HTTPS domena i odgovarajući registrirani OAuth callback.

## Provjere i produkcija

```sh
pnpm check
pnpm test
pnpm build
pnpm start
```

GitHub Actions izvodi ove provjere za push i pull request. `pnpm start` poslužuje
`dist/index.js` i `dist/public/`. Docker slika radi istu izgradnju; konfiguraciju
predajte pri pokretanju, primjerice `docker run --env-file .env -p 3000:3000 mansalpha`.
Ne ugrađujte tajne u sliku. Prije promjena sheme napravite sigurnosnu kopiju baze;
`pnpm db:push` generira i odmah primjenjuje migracije.

`pnpm dev:static` i `pnpm build:static` služe samo statičkom klijentu. Prijava,
privatno spremanje i tRPC zahtijevaju Express poslužitelj. Mediji pod
`/manus-storage/` ovise o postojećoj Manus infrastrukturi; samostalni hosting
mora zasebno osigurati te datoteke ili usmjeravanje na pohranu.

`server/_core/publicConfig.ts` izlaže samo imenovane javne vrijednosti. Tajne
ostaju na poslužitelju. `.env`, privatni uvozi i generirane datoteke izuzeti su
iz Gita i Docker konteksta. Postojeći `noindex,nofollow` zadržan je dok se ne
potvrdi da je sadržaj spreman za indeksiranje.

import express from "express";
import { createServer, type Server } from "node:http";
import { mkdtemp, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { serveStatic } from "./_core/vite";
import { APP_PATHS } from "../shared/routes";

describe("production HTTP routing", () => {
  let server: Server;
  let directory: string;
  let origin: string;
  beforeAll(async () => {
    directory = await mkdtemp(path.join(tmpdir(), "mansalpha-static-"));
    await writeFile(
      path.join(directory, "index.html"),
      '<html><body><div id="root"></div></body></html>',
    );
    await writeFile(path.join(directory, "test.js"), "console.log('asset');");
    const app = express();
    serveStatic(app, directory);
    server = createServer(app);
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    const address = server.address();
    if (!address || typeof address === "string")
      throw new Error("Missing server address");
    origin = `http://127.0.0.1:${address.port}`;
  });
  afterAll(async () => {
    if (server?.listening)
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve())),
      );
    if (directory) await rm(directory, { recursive: true, force: true });
  });
  it("serves every registered page including query-string links", async () => {
    for (const route of APP_PATHS) {
      expect((await fetch(`${origin}${route}?q=test`)).status).toBe(200);
    }
  });
  it("returns real 404s for unknown pages and missing assets", async () => {
    for (const route of [
      "/missing-page",
      "/404",
      "/missing.js",
      "/assets/missing.css",
    ]) {
      expect((await fetch(origin + route)).status).toBe(404);
    }
  });
  it("returns JSON for unknown API endpoints", async () => {
    const response = await fetch(`${origin}/api/missing`);
    expect(response.status).toBe(404);
    expect(await response.json()).toEqual({ error: "API route not found" });
  });
  it("serves existing assets and rejects unsupported methods", async () => {
    expect(await (await fetch(`${origin}/test.js`)).text()).toContain(
      "console.log",
    );
    expect(
      (await fetch(`${origin}/knjiznica`, { method: "POST" })).status,
    ).toBe(404);
  });
});
